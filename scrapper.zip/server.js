const express = require('express');
const puppeteer = require('puppeteer');

// express app
const app = express();

// listen for requests
app.listen(80);

app.get('/', (req, res) => {
  // res.send('<p>home page</p>');
  console.log('Url Hitted');
  res.sendFile('./views/index.html', { root: __dirname });

  (async () => {
    // Launch the browser and open a new blank page
    const browser = await puppeteer.launch({
          headless: false,
          defaultViewport: false,
          userDataDir : './tmp'
      });
    const page = await browser.newPage();
  
    // Navigate the page to a URL
    await page.goto('https://www.myntra.com/handbags?rawQuery=handbags');
      
    console.log('Scrappping Started');
  
    //const productContainers = await page.$$('.s-result-list.s-search-results.sg-row > .s-result-item.s-asin');
    
    /* for(const productContainer of productContainers){
      const title = await page.evaluate(el => el.querySelector("h2 > a > span").textContent, productContainer);
      console.log(title);
    } */
  
    // Print the full titl
    //console.log('This is amazon');
  
    //await browser.close();
  })();

});

app.get('/about', (req, res) => {
  // res.send('<p>about page</p>');
  console.log('Url Hitted');
  res.sendFile('./views/about.html', { root: __dirname });
});

// redirects
app.get('/about-us', (req, res) => {
    console.log('Url Hitted');
  res.redirect('/about');
});

// 404 page
app.use((req, res) => {
  console.log('Url Hitted');
  res.status(404).sendFile('./views/404.html', { root: __dirname });
});