const puppeteer = require('puppeteer');
const axios = require('axios');

const start = (req, res) => {
    
    console.log('Ajio Scrapping for '+req.params.keyword+' keyword started');
    
    res.render('scrapping', { site: 'Ajio' });

    //Scrapping code here

    (async () => {
        
        const proxy = 'brd.superproxy.io:22225';
        const username = 'brd-customer-hl_4b2b55d2-zone-residential';
        const password = 'f31tx7e626cl';

        // Launch the browser and open a new blank page
        const browser = await puppeteer.launch({
            headless: false,
            defaultViewport: false,
            userDataDir: "/tmp"
        });

        const page = await browser.newPage();
        await page.setDefaultNavigationTimeout(0);
        

        let website = req.params.website;
        let keyword = req.params.keyword;
        let request_id = req.params.request_id;
        let isLastPage = false;
        let page_number = 1;
        let number_of_products = 0;

        const site_url = 'https://www.ajio.com/search/?text='+req.params.keyword;
        await page.goto(site_url, {
            waitUntil: 'load'
        });

        let scroll = true;
        var scrolled = 0;
        var number_of_pages = req.params.limit;
        var number_of_scrolls = number_of_pages * 5;
        var product_count = 0;
        var product_div = 0;

        console.log('============= Scrolling Page ==============');

        while (scroll) {
            await page.evaluate(async () => {
                var totalHeight = 0;
                var distance = 500;
                var scrollHeight = document.body.scrollHeight;
                window.scrollBy(0, distance);
                totalHeight += distance;
                if (totalHeight >= scrollHeight - window.innerHeight) {
                    scroll = false;
                }
            });
            scrolled = scrolled + 1;
            if (number_of_scrolls <= scrolled) {
                scroll = false;
            }
            await new Promise(resolve => setTimeout(resolve, 3000 || DEF_DELAY));
        }

        console.log('========== Scrolling Done ===========');

        await new Promise(resolve => setTimeout(resolve, 5000 || DEF_DELAY));
        await page.waitForSelector('#products');
        const productsHandles = await page.$$(
            ".item.rilrtl-products-list__item.item"
        );

        let results = [];
        let data = [];

        for (const producthandle of productsHandles) {

            product_div = product_div + 1;
            let title = '';
            let price = '';
            let mrp = '';
            let product_url = 'Null';
            let product_image = 'Null';

            let product_id = '';
            let star_rating = '';
            let number_of_ratings = '';
            let number_of_reviews = '';

            try {
                title = await page.evaluate(
                    (el) => el.querySelector(".contentHolder > .nameCls").textContent,
                    producthandle
                );    
            } catch (error) { }
    
            try {
                price = await page.evaluate(
                    (el) => el.querySelector(".price").textContent,
                    producthandle
                );
            } catch (error) { }
    
            try {
                mrp = await page.evaluate(
                    (el) => el.querySelector(".orginal-price").textContent,
                    producthandle
                );
            } catch (error) { }

            try {
                product_image = await page.evaluate(
                    (el) => el.querySelector(".imgHolder > div > img").getAttribute("src"),
                    producthandle
                );
            } catch (error) { }
    
            try {
                product_url = await page.evaluate(
                    (el) => el.querySelector("a.rilrtl-products-list__link").getAttribute("href"),
                    producthandle
                );
            } catch (error) { }

            product_url = 'https://ajio.com' + product_url;

            if(product_image !== null && product_image !== "Null"){
                console.log(title);
                console.log(price);
                console.log(product_image);
                console.log(number_of_ratings);
                console.log(product_url);
                console.log('---------------  ===  ---------------');

                //Send To Server

                data.push({ title, price, mrp, product_url, product_image, product_id, star_rating, number_of_ratings, number_of_reviews });
                
                product_count = product_count + 1;
                number_of_products = number_of_products + 1;

                if(product_count > 50){
                    
                    results.push({website, request_id, keyword, page_number, data});
                    
                    await axios.post("https://jholashop.com/webhook/scrappy", {
                        results: results
                    }).then((response) => {
                        console.log(response.data);
                        console.log('<========= Page '+page_number+' Scrapping Completed and Posted ==========>');
                    })
                    .catch((error) => {
                        console.log(error);
                    }); 
                    
                    page_number = page_number + 1;
                    product_count = 0;
                    
                    results = [];
                    data = [];
                    
                }

            }
        }

        if(data.length > 0){
                    
            results.push({website, request_id, keyword, page_number, data});
            
            await axios.post("https://jholashop.com/webhook/scrappy", {
                results: results
            }).then((response) => {
                console.log(response.data);
                console.log('<========= Page '+page_number+' Scrapping Completed and Posted ==========>');
            })
            .catch((error) => {
                console.log(error);
            }); 
            
            page_number = page_number + 1;
            product_count = 0;
            
            results = [];
            data = [];
            
        }
    
    
    
            
        console.log('<========== Products Found : '+number_of_products+' ==========>');

        // Print the full title
        //console.log('This is amazon');

        await browser.close();

    })();


}   


module.exports = {
    start
}