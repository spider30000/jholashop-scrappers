const puppeteer = require('puppeteer');
const axios = require('axios');
const { Cluster } = require("puppeteer-cluster");

const start = (req, res) => {

    console.log('Ajio Details Scrapping for');

    res.render('scrapping', { site: 'Ajio' });

    //Scrapping code here

    (async () => {

        let status_on = false;
        while(!status_on){
            await axios.post("https://jholashop.com/webhook/scrappy-status", {
                status: 1
            }).then((response) => {
                status_on = true;
                console.log(response.data);
            })
            .catch((error) => {
                //console.log(error);
            });
        }

        let results = [];

        const cluster = await Cluster.launch({
            concurrency: Cluster.CONCURRENCY_CONTEXT,
            maxConcurrency: 10,
            monitor: false,
            timeout: 60000000,
            puppeteerOptions: {
                headless: false,
                defaultViewport: false,
                userDataDir: "./tmp"
            },
        });

        const urls_sets = req.body.urls;

        cluster.on("taskerror", (err, data) => {
            console.log(`Error crawling ${data}: ${err.message}`);
        });

        await cluster.task(async ({ page, data: urls_set }) => {
            
            await page.setDefaultNavigationTimeout(0);

            let urls = urls_set;

            let website = 'ajio';
            let request_id = '';
            let isLastPage = false;
            let page_scrapped = 0;
            let number_of_products = urls.length;
            let results = [];
            while (!isLastPage) {

                // Navigate the page to a URL

                let site_url = urls[page_scrapped];
                await page.goto(site_url, {
                    waitUntil: 'load'
                });

                let data = [];

                await new Promise(resolve => setTimeout(resolve, 1000));

                let valid_page = (await page.$('.prod-content')) !== null;

                if (valid_page) {

                    await page.waitForSelector('.prod-content', { visible: true });

                    console.log('<========= Scrapping Page ' + page_scrapped + ' Started ==========>');

                    let title = '';
                    let price = '';
                    let mrp = '';
                    let bullets = '';
                    let description = '';
                    let number_of_answers = '';
                    let number_of_ratings = '';
                    let number_of_reviews = '';
                    let review_page_url = '';
                    let images = [];

                    title = await page.evaluate(() => {

                        try {
                            return document.querySelector('.prod-name').textContent;
                        } catch {
                            return '';
                        }

                    });

                    price = await page.evaluate(() => {
                        try {
                            pp = document.querySelector('.prod-sp').textContent;
                            return pp;
                        } catch {
                            pp = 0;
                            return pp;
                        }
                    });

                    mrp = await page.evaluate(() => {
                        try {
                            return document.querySelector('.prod-cp').textContent;
                        } catch { return ''; }
                    });

                    bullets = await page.evaluate(() => {
                        try {
                            return document.querySelector('.prod-desc').innerHTML;
                        } catch { return ''; }

                    });

                    await page.waitForSelector('.slick-initialized.slick-slider.slick-vertical > .slick-list > .slick-track > .slick-slide', { visible: true });

                    const thumbnails = await page.$$('.slick-vertical > .slick-list > .slick-track > .slick-slide > .img-container');

                    // Loop through the elements and click on each one
                    const next_button = await page.$('.image-slick-container > .slick-slider > button.slick-arrow.slick-next');
                    let img_count = Math.round(thumbnails.length / 2);
                    for (let i = 0; i <= img_count; i++) {
                        await next_button.click();
                        // Wait for some time (optional) to observe the result, replace with your use case
                        await new Promise(resolve => setTimeout(resolve, 500));
                    }

                    const images_divs = await page.$$('.image-slick-container > div > div > div > div > div');

                    // Loop through the elements and click on each one
                    for (const images_div of images_divs) {
                        var img = '';
                        try {
                            img = await page.evaluate(
                                (el) => el.querySelector("img").getAttribute("src"),
                                images_div
                            );
                        } catch (error) { }

                        images.push(img);

                    }


                    let product_url = site_url;

                    results.push({ title, price, mrp, product_url, number_of_ratings, number_of_reviews, number_of_answers, images, bullets, description, review_page_url });
                } else {
                    console.log('<========= Invalid Product Page ============>');
                    await axios.post("https://jholashop.com/webhook/scrappy-delete-product", {
                        url: site_url
                    }).then((response) => {
                        console.log(response.data);
                    })
                    .catch((error) => {
                        console.log(error);
                    });
                }
                page_scrapped = page_scrapped + 1;

                if (page_scrapped >= number_of_products) {
                    isLastPage = true;
                }


            }

            if(results.length > 0){

                await axios.post("https://jholashop.com/webhook/scrappy-product-details", {
                    results: results
                }).then((response) => {
                    console.log(response.data);
                })
                .catch((error) => {
                    console.log(error);
                });
            
            }

            console.log('<========== Products Scrapped : ' + number_of_products + ' ==========>');


        });

        for (const urls_set of urls_sets) {
            await cluster.queue(urls_set);
        }

        await cluster.idle();
        await cluster.close();

        let status_off = false;
        while(!status_off){
            await axios.post("https://jholashop.com/webhook/scrappy-status", {
                status: 0
            }).then((response) => {
                status_off = true;
                console.log(response.data);
            })
            .catch((error) => {
                //console.log(error);
            });
        }

    })();

}

module.exports = {
    start
}