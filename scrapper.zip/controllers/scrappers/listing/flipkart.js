const axios = require('axios');

const start = (req, res, page) => {

    console.log('Flipkart Scrapping for '+req.params.keyword+' keyword started');
    
    (async () => {

        let website = 'flipkart';
        let keyword = req.params.keyword;
        let request_id = req.params.request_id;
        let isLastPage = false;
        let page_number = 1;
        let number_of_products = 0;
        while (!isLastPage) {

            // Navigate the page to a URL
            const site_url = 'https://www.flipkart.com/search?q='+req.params.keyword+'&page='+page_number;
            await page.goto(site_url, {
                waitUntil: 'load'
            });

            let results = [];
            let data = [];

            await new Promise(resolve => setTimeout(resolve, 1000));

            let pagesAvailable = (await page.$('._1LKTO3')) !== null;

            console.log('<========= Scrapping Page '+page_number+' Started ==========>');

            await page.waitForSelector('div._13oc-S', { visible: true });

            let isGridLayout = (await page.$('.s1Q9rs')) !== null;

            const productContainers = await page.$$('div._13oc-S > div');

            await page.waitForSelector('div._13oc-S', { visible: true });

            for (const productContainer of productContainers) {
                let title = '';
                let price = '';
                let mrp = '';
                let product_url = '';
                let product_image = '';

                let product_id = '';
                let star_rating = '';
                let number_of_ratings = '';
                let number_of_reviews = '';

                if(isGridLayout){

                    //// Grid Layout

                    try {
                        title = await page.evaluate(
                            el => el.querySelector('.s1Q9rs').textContent,
                            productContainer
                        );
                    } catch { }

                    if(title == ''){
                        try {
                            title = await page.evaluate(
                                el => el.querySelector('.IRpwTa').textContent,
                                productContainer
                            );
                        } catch { }
                    }


                    try {
                        price = await page.evaluate(
                            el => el.querySelector('._30jeq3').textContent,
                            productContainer
                        );
                    } catch { }

                    try {
                        mrp = await page.evaluate(
                            el => el.querySelector('._3I9_wc').textContent,
                            productContainer
                        );
                    } catch { }


                    try {
                        product_url = await page.evaluate(
                            el => el.querySelector('a.s1Q9rs').getAttribute('href'),
                            productContainer
                        );
                        product_url = 'https://flipkart.com' + product_url;
                    } catch { }

                    if(product_url == ''){
                        try {
                            product_url = await page.evaluate(
                                el => el.querySelector('a._2UzuFa').getAttribute('href'),
                                productContainer
                            );
                            product_url = 'https://flipkart.com' + product_url;
                        } catch { }
                    }

                    try {
                        product_image = await page.evaluate(
                            el => el.querySelector('.CXW8mj > img').getAttribute('src'),
                            productContainer
                        );
                    } catch { }

                    if(product_image == ''){
                        try {
                            product_image = await page.evaluate(
                                el => el.querySelector('._312yBx > img').getAttribute('src'),
                                productContainer
                            );
                        } catch { }
                    }

                    try {
                        product_id = await page.evaluate(
                            el => el.getAttribute('data-id'),
                            productContainer
                        );
                    } catch { }

                    try {
                        number_of_ratings = await page.evaluate(
                            el => el.querySelector('._2_R_DZ').textContent,
                            productContainer
                        );
                    } catch { }
        

                }else{

                    try {
                        title = await page.evaluate(
                            el => el.querySelector('._4rR01T').textContent,
                            productContainer
                        );
                    } catch { }
                    if(title == ''){
                        try {
                            title = await page.evaluate(
                                el => el.querySelector('.IRpwTa').textContent,
                                productContainer
                            );
                        } catch { }
                    }

                    try {
                        price = await page.evaluate(
                            el => el.querySelector('._30jeq3').textContent,
                            productContainer
                        );
                    } catch { }

                    try {
                        mrp = await page.evaluate(
                            el => el.querySelector('._3I9_wc').textContent,
                            productContainer
                        );
                    } catch { }


                    try {
                        product_url = await page.evaluate(
                            el => el.querySelector('a._1fQZEK').getAttribute('href'),
                            productContainer
                        );
                        product_url = 'https://flipkart.com' + product_url;
                    } catch { }

                    if(product_url == ''){
                        try {
                            product_url = await page.evaluate(
                                el => el.querySelector('a._2UzuFa').getAttribute('href'),
                                productContainer
                            );
                            product_url = 'https://flipkart.com' + product_url;
                        } catch { }
                    }

                    try {
                        product_image = await page.evaluate(
                            el => el.querySelector('.CXW8mj > img').getAttribute('src'),
                            productContainer
                        );
                    } catch { }

                    if(product_image == ''){
                        try {
                            product_image = await page.evaluate(
                                el => el.querySelector('._312yBx > img').getAttribute('src'),
                                productContainer
                            );
                        } catch { }
                    }

                    try {
                        product_id = await page.evaluate(
                            el => el.querySelector('div').getAttribute('data-id'),
                            productContainer
                        );
                    } catch { }

                    try {
                        number_of_ratings = await page.evaluate(
                            el => el.querySelector('._2_R_DZ > span > span').textContent,
                            productContainer
                        );
                    } catch { }

                }


                if (product_url !== '') {
                    data.push({ title, price, mrp, product_url, product_image, product_id, star_rating, number_of_ratings, number_of_reviews });
                }

                number_of_products = number_of_products + 1;

                console.log(title);
                console.log(price);
                console.log(product_image);
                console.log(number_of_ratings);
                console.log(product_url);
                console.log('---------------  ===  ---------------');

            }

            results.push({website, request_id, keyword, page_number, data});


            await axios.post("https://jholashop.com/webhook/scrappy", {
                results: results
            }).then((response) => {
                console.log(response.data);
                console.log('<========= Page '+page_number+' Scrapping Completed ==========>');
                page_number = page_number + 1;
            }).catch((error) => {
                console.log(error);
            }); 

            page_number = page_number + 1;

            if(pagesAvailable){
                //await page.waitForSelector('._1LKTO3', { visible: true });
                const isLast = (await page.$('._1LKTO3')) == null;
                isLastPage = isLast;
                if (!isLast) {
                    //await page.click('._1LKTO3');
                    //await page.waitForNavigation();
                }
            }else {
                isLastPage = true;
            }

            if(page_number > req.params.limit){
                isLastPage = true;
            }
            

        }

        console.log('<========== Products Found : '+number_of_products+' ==========>');

        // Print the full title
        //console.log('This is amazon');

    })();
}


module.exports = {
    start
}