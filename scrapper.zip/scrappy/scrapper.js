const express = require('express');
const puppeteer = require('puppeteer');
const axios = require('axios');

// express app
const app = express();

// listen for requests
app.listen(3000);

app.get('/:website/:request_id/:keyword', (req, res) => {

    res.sendFile('./views/scrapper.html', { root: __dirname });

    (async () => {
        // Launch the browser and open a new blank page
        const browser = await puppeteer.launch({
            headless: false,
            defaultViewport: false,
            userDataDir: "/tmp",
            executablePath: "/Applications/Chromium.app/Contents/MacOS/Chromium"
        });
        const page = await browser.newPage();
        await page.setDefaultNavigationTimeout(0);
        // Navigate the page to a URL
        const site_url = 'https://www.amazon.in/s?k='+req.params.keyword;
        await page.goto(site_url, {
            waitUntil: 'load'
        });


        let website = req.params.website;
        let keyword = req.params.keyword;
        let request_id = req.params.request_id;
        let isLastPage = false;
        let page_number = 1;
        let number_of_products = 0;
        while (!isLastPage) {


            let results = [];
            let data = [];

            let pagesAvailable = (await page.$('.s-pagination-item.s-pagination-next')) !== null;
            
            await page.waitForSelector('.s-main-slot.s-result-list.s-search-results.sg-row > .s-result-item.s-asin', { visible: true });

            console.log('<========= Scrapping Page '+page_number+' Started ==========>');

            const productContainers = await page.$$('.s-main-slot.s-result-list.s-search-results.sg-row > .s-result-item.s-asin');

            for (const productContainer of productContainers) {
                let title = '';
                let price = '';
                let mrp = '';
                let product_url = '';
                let product_image = '';

                let product_id = '';
                let star_rating = '';
                let number_of_ratings = '';
                let number_of_reviews = '';

                try {
                    title = await page.evaluate(
                        el => el.querySelector('h2 > a > span').textContent,
                        productContainer
                    );
                } catch { }
                try {
                    price = await page.evaluate(
                        el => el.querySelector('.a-price > span.a-offscreen').textContent,
                        productContainer
                    );
                } catch { }
                try {
                    mrp = await page.evaluate(
                        el => el.querySelector('.a-price.a-text-price > span.a-offscreen').textContent,
                        productContainer
                    );
                } catch { }

                try {
                    product_url = await page.evaluate(
                        el => el.querySelector('.a-link-normal').getAttribute('href'),
                        productContainer
                    );
                    product_url = 'https://amazon.in' + product_url;
                } catch { }

                try {
                    product_image = await page.evaluate(
                        el => el.querySelector('.s-image').getAttribute('src'),
                        productContainer
                    );
                } catch { }

                try {
                    product_id = await page.evaluate(
                        el => el.getAttribute('data-asin'),
                        productContainer
                    );
                } catch { }

                try {
                    number_of_ratings = await page.evaluate(
                        el => el.querySelector('a.a-link-normal.s-underline-text.s-underline-link-text.s-link-style > span.a-size-base.s-underline-text').textContent,
                        productContainer
                    );
                } catch { }


                if (product_url !== '') {
                    data.push({ title, price, mrp, product_url, product_image, product_id, star_rating, number_of_ratings, number_of_reviews });
                }

                number_of_products = number_of_products + 1;

                //console.log(title);
                //console.log(number_of_ratings);

            }

            results.push({website, request_id, keyword, page_number, data});


           /*  axios.post("https://jholashop.com/webhook/scrappy", {
                results: results
            }).then((response) => {
                console.log(response);
                console.log('<========= Page '+page_number+' Scrapping Completed ==========>');
                page_number = page_number + 1;
            })
            .catch((error) => {
                console.log(error);
            }); */

            page_number = page_number + 1;

            if(page_number == 1){
                if(pagesAvailable){
                    await page.waitForSelector('.s-pagination-item.s-pagination-next', { visible: true });
                    const isLast = (await page.$('.s-pagination-item.s-pagination-next.s-pagination-disabled')) !== null;
                    isLastPage = isLast;
                    if (!isLast) {
                        await page.click('.s-pagination-item.s-pagination-next');
                        //await page.waitForNavigation();
                    }
                }else {
                    isLastPage = true;
                }
            }else{
                await page.waitForSelector('.s-pagination-item.s-pagination-next', { visible: true });
                const isLast = (await page.$('.s-pagination-item.s-pagination-next.s-pagination-disabled')) !== null;
                isLastPage = isLast;
                if (!isLast) {
                    await page.click('.s-pagination-item.s-pagination-next');
                    //await page.waitForNavigation();
                }
            }

            

        }


        console.log('<========== Products Found : '+number_of_products+' ==========>');

        // Print the full title
        //console.log('This is amazon');

        await browser.close();

    })();

});


// 404 page
app.use((req, res) => {
    res.status(404).sendFile('./views/404.html', { root: __dirname });
});