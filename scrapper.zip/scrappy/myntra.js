const express = require('express');
const puppeteer = require('puppeteer');
const axios = require('axios');

// express app
const app = express();

// listen for requests
app.listen(3000);

app.get('/:website/:request_id/:keyword', (req, res) => {

    res.sendFile('./views/scrapper.html', { root: __dirname });

    (async () => {
        // Launch the browser and open a new blank page
        const browser = await puppeteer.launch({
            headless: false,
            defaultViewport: false,
            userDataDir: "/tmp",
            executablePath: "/Applications/Chromium.app/Contents/MacOS/Chromium"
        });
        const page = await browser.newPage();

        await page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0.3 Safari/605.1.15');

        await page.setDefaultNavigationTimeout(0);
        
        // Navigate the page to a URL
        let query = req.params.keyword;
        query = query.replace(' ', '-')
        const site_url = 'https://myntra.com/'+query+'?rawQuery='+req.params.keyword;
        await page.goto(site_url, {
            waitUntil: 'load'
        });

        
        // Print the full title
        console.log('This is amazon');

        await browser.close();

    })();

});


// 404 page
app.use((req, res) => {
    res.status(404).sendFile('./views/404.html', { root: __dirname });
});