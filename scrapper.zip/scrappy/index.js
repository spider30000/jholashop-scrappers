const puppeteer = require('puppeteer');
const axios = require('axios');

(async () => {
    // Launch the browser and open a new blank page
    const browser = await puppeteer.launch({
        headless: false,
        defaultViewport: false,
        userDataDir: "/tmp",
        executablePath: "/Applications/Chromium.app/Contents/MacOS/Chromium"
    });
    const page = await browser.newPage();
    await page.setDefaultNavigationTimeout(0);
    // Navigate the page to a URL
    await page.goto('https://www.amazon.in/s?k=mens+perfumes+for+christmas', {
        waitUntil : 'load'
    });


    let results = [];
    let isLastPage = false;
    while (!isLastPage) {

        await page.waitForSelector('.s-pagination-item.s-pagination-next');

        const productContainers = await page.$$('.s-main-slot.s-result-list.s-search-results.sg-row > .s-result-item.s-asin');

        for (const productContainer of productContainers) {
            let title = '';
            let price = '';
            let mrp = '';
            let product_url = '';
            let product_image = '';

            try {
                title = await page.evaluate(
                    el => el.querySelector('h2 > a > span').textContent,
                    productContainer
                );
            } catch { }
            try {
                price = await page.evaluate(
                    el => el.querySelector('.a-price > span.a-offscreen').textContent,
                    productContainer
                );
            } catch { }
            try {
                mrp = await page.evaluate(
                    el => el.querySelector('.a-price.a-text-price > span.a-offscreen').textContent,
                    productContainer
                );
            } catch { }

            try {
                product_url = await page.evaluate(
                    el => el.querySelector('.a-link-normal').getAttribute('href'),
                    productContainer
                );
                product_url = 'https://amazon.in' + product_url;
            } catch { }

            try {
                product_image = await page.evaluate(
                    el => el.querySelector('.s-image').getAttribute('src'),
                    productContainer
                );
            } catch { }

            if (product_url !== '') {
                results.push({ title, price, mrp, product_url, product_image });
            }

        }

        await page.waitForSelector('.s-pagination-item.s-pagination-next', { visible: true });
        const isLast = (await page.$('.s-pagination-item.s-pagination-next.s-pagination-disabled')) !== null;
        isLastPage = isLast;
        if (!isLast) {
            await page.click('.s-pagination-item.s-pagination-next');
            //await page.waitForNavigation();
        }

    }

    axios.post("https://jholashop.com/webhook/scrappy", {
        results: results
    }).then((response) => {
        console.log('Process completed');
    });

    console.log(results.length);

    // Print the full title
    //console.log('This is amazon');

    await browser.close();
})();