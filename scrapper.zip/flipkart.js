const express = require('express');
const puppeteer = require('puppeteer');
const axios = require('axios');

// express app
const app = express();

// listen for requests
app.listen(3000);

app.get('/product-details', (req, res) => {

    res.sendFile('./views/scrapper.html', { root: __dirname });

    (async () => {

        // Launch the browser and open a new blank page
        const browser = await puppeteer.launch({
            headless: false,
            defaultViewport: false,
            userDataDir: "/tmp"
        });

        const page = await browser.newPage();


        await page.setDefaultNavigationTimeout(0);

        
        const urls = [
            "https://www.flipkart.com/puma-future-rider-twofold-sneakers-women/p/itm0c360cdda478c",
            "https://www.flipkart.com/skechers-glide-step-sport-liv-sneakers-women/p/itm40c4ad8584c66",
            "https://www.flipkart.com/crocs-classic-women-black-clogs/p/itme48f835d84bb6"
        ];
    
        let website = 'flipkart';
        let request_id = '';
        let isLastPage = false;
        let page_scrapped = 0;
        let number_of_products = urls.length;
        let results = [];
        while (!isLastPage) {

            // Navigate the page to a URL

            let site_url = urls[page_scrapped];
            await page.goto(site_url, {
                waitUntil: 'load'
            });

            let data = [];

            await new Promise(resolve => setTimeout(resolve, 1000));
            
            await page.waitForSelector('span.B_NuCI', { visible: true });

            console.log('<========= Scrapping Page '+page_scrapped+' Started ==========>');

            let title = '';
            let price = '';
            let mrp = '';
            let bullets = '';
            let description = '';
            let number_of_answers = '';
            let number_of_ratings = '';
            let review_page_url = '';
            let images = [];

            title = await page.evaluate(() => {

                try {
                    return document.querySelector('span.B_NuCI').textContent;
                } catch {
                    return '';
                 }

            });
            title = title.trim();
            price = await page.evaluate(() => {
                try {
                    pp = document.querySelector('div._30jeq3').textContent;
                    
                    return pp;
                } catch { 
                    pp = 0; 
                    return pp;
                }
            });

            mrp = await page.evaluate(() => {
                try {
                    return document.querySelector('div._3I9_wc').textContent;
                } catch { return ''; }
            });

            bullets = await page.evaluate(() => {
                try {
                    return document.querySelector('.X3BRps._13swYk').innerHTML;
                } catch { return ''; }
    
            });
            description = await page.evaluate(() => {
                try {
                    return document.querySelector('._1mXcCf.RmoJU3').innerHTML;
                } catch { return ''; }
            });

            number_of_reviews = await page.evaluate(() => {
                try {
                    return document.querySelector('span._2_R_DZ._2IRzS8').textContent;
                } catch { return ''; }
            });

            review_page_url = await page.evaluate(() => {
                try {
                    return document.querySelector(".JOpGWq._33R3aa > a").getAttribute('href');
                } catch { return ''; }
            });

            review_page_url = 'https://www.flipkart.com'+review_page_url;

            const thumbnails = await page.$$('._20Gt85');

            // Loop through the elements and click on each one
            for (let i = 0; i < thumbnails.length; i++) {
                await thumbnails[i].click();
                // Wait for some time (optional) to observe the result, replace with your use case
                await new Promise(resolve => setTimeout(resolve, 500));

                img = await page.evaluate(() => {
                    try {
                        return document.querySelector("._2r_T1I._396QI4").getAttribute('src');
                    } catch { return ''; }
                });
                if(img !== ''){
                    images.push(img);
                }
            }


            let product_url = site_url;

            results.push({title, price, mrp, product_url, number_of_ratings, number_of_reviews, number_of_answers, images, bullets, description, review_page_url });   
        
            page_scrapped = page_scrapped + 1;

            if(page_scrapped >= number_of_products){
                isLastPage = true;
            }
            

        }

        axios.post("https://jholashop.com/webhook/scrappy-product-details", {
            results: results
        }).then((response) => {
            console.log(response);
        })
        .catch((error) => {
            console.log(error);
        }); 

        console.log('<========== Products Scrapped : '+number_of_products+' ==========>');

        await browser.close();

    })();

});


// 404 page
app.use((req, res) => {
    res.status(404).sendFile('./views/404.html', { root: __dirname });
});