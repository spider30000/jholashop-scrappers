const express = require('express');
const scrapper = require('../controllers/scrapper');

const router = express.Router();

router.get('/:request_id/:limit/:keyword', scrapper.scrapeWebsite);

router.post('/details/:website', scrapper.mapDetailsWebsite);

router.post('/product-details', scrapper.scrapeDetailsWebsite);

module.exports = router;