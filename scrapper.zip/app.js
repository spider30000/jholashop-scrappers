const express = require('express');
const morgan = require('morgan');
const scrapperRoutes = require('./routes/scrapperRoutes');
const bodyParser = require('body-parser');

// express app
const app = express();

app.listen(3000);

// register view engine
app.set('view engine', 'ejs');

// middleware & static files
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(morgan('dev'));
app.use((req, res, next) => {
  res.locals.path = req.path;
  next();
});

// routes
app.get('/', (req, res) => {
  console.log('Url Hitted');
  res.sendFile('./views/index.html', { root: __dirname });
});

// blog routes
app.use('/scrapper', scrapperRoutes);

// 404 page
app.use((req, res) => {
  res.status(404).render('404', { title: '404' });
});