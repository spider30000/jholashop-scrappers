const express = require('express');
const puppeteer = require('puppeteer');
const axios = require('axios');
const morgan = require('morgan');
const bodyParser = require('body-parser');

// express app
const app = express();

// listen for requests
app.listen(3000);


// middleware & static files
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(morgan('dev'));
app.use((req, res, next) => {
  res.locals.path = req.path;
  next();
});


app.post('/scrappy/product-details', (req, res) => {

    console.log('Url Hitted');
    console.log(req.body.urls);
    res.sendFile('./views/scrapper.html', { root: __dirname });

});


// 404 page
app.use((req, res) => {
    res.status(404).sendFile('./views/404.html', { root: __dirname });
});