const express = require('express');
const puppeteer = require('puppeteer');
const axios = require('axios');

// express app
const app = express();

// listen for requests
app.listen(3000);

app.get('/:website/:request_id/:keyword', (req, res) => {

    res.sendFile('./views/scrapper.html', { root: __dirname });

    (async () => {
        // Launch the browser and open a new blank page
        const browser = await puppeteer.launch({
            headless: false,
            defaultViewport: false,
            userDataDir: "/tmp",
            executablePath: "/Applications/Chromium.app/Contents/MacOS/Chromium"
        });
        const page = await browser.newPage();
        await page.setDefaultNavigationTimeout(0);
        


        let website = req.params.website;
        let keyword = req.params.keyword;
        let request_id = req.params.request_id;
        let isLastPage = false;
        let page_number = 1;
        let number_of_products = 0;
        while (!isLastPage) {

            // Navigate the page to a URL
            const site_url = 'https://www.flipkart.com/search?q='+req.params.keyword+'&page='+page_number;
            await page.goto(site_url, {
                waitUntil: 'load'
            });

            let results = [];
            let data = [];

            await new Promise(resolve => setTimeout(resolve, 1000));

            let pagesAvailable = (await page.$('._1LKTO3')) !== null;

            console.log('<========= Scrapping Page '+page_number+' Started ==========>');

            await page.waitForSelector('div._13oc-S', { visible: true });

            let isGridLayout = (await page.$('.s1Q9rs')) !== null;

            const productContainers = await page.$$('div._13oc-S > div');

            await page.waitForSelector('div._13oc-S', { visible: true });

            for (const productContainer of productContainers) {
                let title = '';
                let price = '';
                let mrp = '';
                let product_url = '';
                let product_image = '';

                let product_id = '';
                let star_rating = '';
                let number_of_ratings = '';
                let number_of_reviews = '';

                if(isGridLayout){

                    //// Grid Layout

                    try {
                        title = await page.evaluate(
                            el => el.querySelector('.s1Q9rs').textContent,
                            productContainer
                        );
                    } catch { }


                    try {
                        price = await page.evaluate(
                            el => el.querySelector('._30jeq3').textContent,
                            productContainer
                        );
                    } catch { }

                    try {
                        mrp = await page.evaluate(
                            el => el.querySelector('._3I9_wc').textContent,
                            productContainer
                        );
                    } catch { }


                    try {
                        product_url = await page.evaluate(
                            el => el.querySelector('a.s1Q9rs').getAttribute('href'),
                            productContainer
                        );
                        product_url = 'https://flipkart.com' + product_url;
                    } catch { }

                    try {
                        product_image = await page.evaluate(
                            el => el.querySelector('.CXW8mj').getAttribute('src'),
                            productContainer
                        );
                    } catch { }

                    try {
                        product_id = await page.evaluate(
                            el => el.getAttribute('data-id'),
                            productContainer
                        );
                    } catch { }

                    try {
                        number_of_ratings = await page.evaluate(
                            el => el.querySelector('._2_R_DZ').textContent,
                            productContainer
                        );
                    } catch { }
        

                }else{

                    try {
                        title = await page.evaluate(
                            el => el.querySelector('._4rR01T').textContent,
                            productContainer
                        );
                    } catch { }


                    try {
                        price = await page.evaluate(
                            el => el.querySelector('._30jeq3').textContent,
                            productContainer
                        );
                    } catch { }

                    try {
                        mrp = await page.evaluate(
                            el => el.querySelector('._3I9_wc').textContent,
                            productContainer
                        );
                    } catch { }


                    try {
                        product_url = await page.evaluate(
                            el => el.querySelector('a._1fQZEK').getAttribute('href'),
                            productContainer
                        );
                        product_url = 'https://flipkart.com' + product_url;
                    } catch { }

                    try {
                        product_image = await page.evaluate(
                            el => el.querySelector('.CXW8mj').getAttribute('src'),
                            productContainer
                        );
                    } catch { }

                    try {
                        product_id = await page.evaluate(
                            el => el.querySelector('div').getAttribute('data-id'),
                            productContainer
                        );
                    } catch { }

                    try {
                        number_of_ratings = await page.evaluate(
                            el => el.querySelector('._2_R_DZ > span > span').textContent,
                            productContainer
                        );
                    } catch { }

                }


                if (product_url !== '') {
                    data.push({ title, price, mrp, product_url, product_image, product_id, star_rating, number_of_ratings, number_of_reviews });
                }

                number_of_products = number_of_products + 1;

                console.log(title);
                console.log(number_of_ratings);
                console.log(price);

            }

            results.push({website, request_id, keyword, page_number, data});


            axios.post("https://jholashop.com/webhook/scrappy", {
                results: results
            }).then((response) => {
                console.log(response);
                console.log('<========= Page '+page_number+' Scrapping Completed ==========>');
                page_number = page_number + 1;
            })
            .catch((error) => {
                console.log(error);
            }); 

            page_number = page_number + 1;

            if(pagesAvailable){
                //await page.waitForSelector('._1LKTO3', { visible: true });
                const isLast = (await page.$('._1LKTO3')) == null;
                isLastPage = isLast;
                if (!isLast) {
                    //await page.click('._1LKTO3');
                    //await page.waitForNavigation();
                }
            }else {
                isLastPage = true;
            }

            if(page_number > 4){
                isLastPage = true;
            }
            

        }

        console.log('<========== Products Found : '+number_of_products+' ==========>');

        // Print the full title
        //console.log('This is amazon');

        await browser.close();

    })();

});


// 404 page
app.use((req, res) => {
    res.status(404).sendFile('./views/404.html', { root: __dirname });
});