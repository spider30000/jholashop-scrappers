const express = require('express');
const puppeteer = require('puppeteer');
const axios = require('axios');
const morgan = require('morgan');
const bodyParser = require('body-parser');

// express app
const app = express();

// listen for requests
app.listen(3000);


// middleware & static files
app.use(express.static('public'));
app.use(bodyParser.json());
app.use(morgan('dev'));
app.use((req, res, next) => {
  res.locals.path = req.path;
  next();
});

app.post('/scrappy/product-details', (req, res) => {

    res.sendFile('./views/scrapper.html', { root: __dirname });

    console.log('Url Hitted');

    (async () => {

        // Launch the browser and open a new blank page
        const browser = await puppeteer.launch({
            headless: false,
            defaultViewport: false,
            userDataDir: "/tmp"
        });

        const page = await browser.newPage();

        await page.setDefaultNavigationTimeout(0);

        const urls = req.body.urls;
    
        let website = 'amazon';
        let request_id = '';
        let isLastPage = false;
        let page_scrapped = 0;
        let number_of_products = urls.length;
        let results = [];
        while (!isLastPage) {

            // Navigate the page to a URL

            let site_url = urls[page_scrapped];
            await page.goto(site_url, {
                waitUntil: 'load'
            });

            let data = [];

            await new Promise(resolve => setTimeout(resolve, 1000));
            
            await page.waitForSelector('#title', { visible: true });

            console.log('<========= Scrapping Page '+page_scrapped+' Started ==========>');

            let title = '';
            let price = '';
            let mrp = '';
            let bullets = '';
            let description = '';
            let number_of_answers = '';
            let number_of_ratings = '';
            let review_page_url = '';
            let images = [];

            title = await page.evaluate(() => {

                try {
                    return document.querySelector('#title').textContent;
                } catch {
                    return '';
                 }

            });
            title = title.trim();
            price = await page.evaluate(() => {
                try {
                    pp = document.querySelector('.priceToPay > .a-offscreen').textContent; 
                    return pp;
                } catch { 
                    return '';
                }
            });

            if(price == ''){
                price = await page.evaluate(() => {
                    try {
                        pp = document.querySelector('.apexPriceToPay > .a-offscreen').textContent;
                        return pp;
                    } catch { 
                        return '';
                    }
                });
            }

            mrp = await page.evaluate(() => {
                try {
                    return document.querySelector('.a-text-price > span').textContent;
                } catch { return ''; }
            });

            bullets = await page.evaluate(() => {
                try {
                    return document.querySelector('#productOverview_feature_div > .a-section').innerHTML;
                } catch { return ''; }
    
            });
            description = await page.evaluate(() => {
                try {
                    return document.querySelector('#featurebullets_feature_div > #feature-bullets').innerHTML;
                } catch { return ''; }
            });

            number_of_reviews = await page.evaluate(() => {
                try {
                    return document.querySelector('#acrCustomerReviewText').textContent;
                } catch { return ''; }
            });

            number_of_answers = await page.evaluate(() => {
               try {
                    return document.querySelector('#askATFLink').textContent;
                } catch { return ''; } 
            });

            review_page_url = await page.evaluate(() => {
                try {
                    return document.querySelector("a[data-hook='see-all-reviews-link-foot']").getAttribute('href');
                } catch { return ''; }
            });

            const thumbnails = await page.$$('.item.imageThumbnail');

            // Loop through the elements and click on each one
            for (let i = 0; i < thumbnails.length; i++) {
                await thumbnails[i].click();
                // Wait for some time (optional) to observe the result, replace with your use case
                await new Promise(resolve => setTimeout(resolve, 500));
            }

            const image_divs = await page.$$('.image.item');

            for await (const image_div of image_divs) {
                try {
                    let img = await page.evaluate(
                        el => el.querySelector('img').getAttribute('src'),
                        image_div
                    );
                        
                    images.push(img);

                } catch { }
            }  
            

            let product_url = site_url;

            results.push({ title, price, mrp, product_url, number_of_ratings, number_of_reviews, number_of_answers, images, bullets, description, review_page_url });
            console.log(title);
            console.log(price);  
           
            page_scrapped = page_scrapped + 1;

            if(page_scrapped >= number_of_products){
                isLastPage = true;
            }
            

        }

        axios.post("https://jholashop.com/webhook/scrappy-product-details", {
            results: results
        }).then((response) => {
            console.log(response);
        })
        .catch((error) => {
            console.log(error);
        }); 

        console.log('<========== Products Scrapped : '+number_of_products+' ==========>');

        await browser.close();

    })();

});


// 404 page
app.use((req, res) => {
    res.status(404).sendFile('./views/404.html', { root: __dirname });
});