const puppeteer = require('puppeteer');
const axios = require('axios');

const start = (req, res) => {

    console.log('Myntra Details Scrapping');
    
    res.render('scrapping', { site: 'Myntra' });
    (async () => {

        // Launch the browser and open a new blank page
        const browser = await puppeteer.launch({
            headless: false,
            defaultViewport: false,
            userDataDir: "/tmp"
        });

        const page = await browser.newPage();


        await page.setDefaultNavigationTimeout(0);

        
        const urls = req.body.urls;
    
        let website = 'myntra';
        let request_id = '';
        let isLastPage = false;
        let page_scrapped = 0;
        let number_of_products = urls.length;
        let results = [];
        while (!isLastPage) {

            // Navigate the page to a URL

            let site_url = urls[page_scrapped];
            await page.goto(site_url, {
                waitUntil: 'load'
            });

            let data = [];

            await new Promise(resolve => setTimeout(resolve, 1000));

            let valid_page = (await page.$('.pdp-name')) !== null;

            if(valid_page){

                await page.waitForSelector('.pdp-name', { visible: true });

                const last_image = await page.$$('.image-grid-col50');
                
                await page.evaluate((el) => el.scrollIntoView(), last_image[last_image.length - 1]);
                
                await new Promise(resolve => setTimeout(resolve, 1000));

                console.log('<========= Scrapping Page '+page_scrapped+' Started ==========>');

                let title = '';
                let price = '';
                let mrp = '';
                let bullets = '';
                let description = '';
                let number_of_answers = '';
                let number_of_ratings = '';
                let number_of_reviews = '';
                let review_page_url = '';
                let images = [];

                title = await page.evaluate(() => {

                    try {
                        return document.querySelector('.pdp-name').textContent;
                    } catch {
                        return '';
                    }

                });
                title = title.trim();
                price = await page.evaluate(() => {
                    try {
                        pp = document.querySelector('.pdp-price').textContent;
                        
                        return pp;
                    } catch { 
                        pp = 0; 
                        return pp;
                    }
                });

                mrp = await page.evaluate(() => {
                    try {
                        return document.querySelector('.pdp-mrp > s').textContent;
                    } catch { return ''; }
                });

                description = await page.evaluate(() => {
                    try {
                        return document.querySelector('.pdp-productDescriptorsContainer').innerHTML;
                    } catch { return ''; }
                });

                number_of_reviews = await page.evaluate(() => {
                    try {
                        return document.querySelector('.index-ratingsCount').textContent;
                    } catch { return ''; }
                });

                review_page_url = await page.evaluate(() => {
                    try {
                        return document.querySelector(".detailed-reviews-allReviews").getAttribute('href');
                    } catch { return ''; }
                });

                review_page_url = 'https://myntra.com'+review_page_url;

                const product_images = await page.$$('.image-grid-col50 > .image-grid-imageContainer > .image-grid-image');
                
                
                for (const product_image of product_images) {
                    let img_text = '';
                    let img = '';
                    try {
                        img_text = await page.evaluate(
                            el => el.getAttribute('style'),
                            product_image
                        );
                    } catch { }
                    if(img_text !== ''){
                        let matches = img_text.match(/(https?:\/\/[^ ]*)/)
                        img = matches[1].replace("&quot", "");
                        if(img !== ''){
                            images.push(img);
                        }
                    }
                }

                console.log(title);
                console.log(price);  
                console.log(number_of_reviews);
                console.log(images);  

                let product_url = site_url;

                results.push({title, price, mrp, product_url, number_of_ratings, number_of_reviews, number_of_answers, images, bullets, description, review_page_url });   
            }else{
                console.log('<========= Invalid Product Page ============>');
            }
            page_scrapped = page_scrapped + 1;

            if(page_scrapped >= number_of_products){
                isLastPage = true;
            }
            

        }

        await axios.post("https://jholashop.com/webhook/scrappy-product-details", {
            results: results
        }).then((response) => {
            console.log(response.data);
        })
        .catch((error) => {
            console.log(error);
        }); 

        console.log('<========== Products Scrapped : '+number_of_products+' ==========>');

        await browser.close();

    })();
}


module.exports = {
    start
}