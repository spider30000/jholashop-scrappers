const puppeteer = require('puppeteer');
const axios = require('axios');
const { Cluster } = require("puppeteer-cluster");

const start = (req, res) => {
    
    console.log('Amazon Details Scrapping for');
    
    res.render('scrapping', { site: 'Amazon' });

    //Scrapping code here



    (async () => {
        
        let results = [];

        const cluster = await Cluster.launch({
            concurrency: Cluster.CONCURRENCY_PAGE,
            maxConcurrency: 10,
            monitor: true,
            timeout: 600000,
            puppeteerOptions: {
                headless: false,
                defaultViewport: false,
                userDataDir: "./tmp"
            },
        });

        
        const urls_sets = req.body.urls;


        cluster.on("taskerror", (err, data) => {
            console.log(`Error crawling ${data}: ${err.message}`);
        });

        await cluster.task(async ({ page, data: url }) => {
 
            let website = url.website;

            

        });

        for (const urls_set of urls_sets) {
            await cluster.queue(urls_set);
        }

        

        await cluster.idle();
        await cluster.close();

    })();
    



    (async () => {

        // Launch the browser and open a new blank page
        const browser = await puppeteer.launch({
            headless: false,
            defaultViewport: false,
            userDataDir: "/tmp"
        });

        const page = await browser.newPage();

        await page.setDefaultNavigationTimeout(0);

        const urls = req.body.urls;
    
        let website = 'amazon';
        let request_id = '';
        let isLastPage = false;
        let page_scrapped = 0;
        let number_of_products = urls.length;
        let results = [];
        while (!isLastPage) {

            // Navigate the page to a URL

            let site_url = urls[page_scrapped];
            await page.goto(site_url, {
                waitUntil: 'load'
            });

            let data = [];

            await new Promise(resolve => setTimeout(resolve, 500));

            let valid_page = (await page.$('#title')) !== null;

            if(valid_page){

                console.log('<========= Scrapping Page '+page_scrapped+' Started ==========>');

                let title = '';
                let price = '';
                let mrp = '';
                let bullets = '';
                let description = '';
                let number_of_answers = '';
                let number_of_ratings = '';
                let number_of_reviews = '';
                let review_page_url = '';
                let images = [];
    
                title = await page.evaluate(() => {
    
                    try {
                        return document.querySelector('#title').textContent;
                    } catch {
                        return '';
                     }
    
                });
                title = title.trim();
                price = await page.evaluate(() => {
                    try {
                        pp = document.querySelector('.priceToPay > .a-offscreen').textContent; 
                        return pp;
                    } catch { 
                        return '';
                    }
                });
    
                if(price == ''){
                    price = await page.evaluate(() => {
                        try {
                            pp = document.querySelector('.apexPriceToPay > .a-offscreen').textContent;
                            return pp;
                        } catch { 
                            return '';
                        }
                    });
                }
    
                mrp = await page.evaluate(() => {
                    try {
                        return document.querySelector('.a-text-price > span').textContent;
                    } catch { return ''; }
                });
    
                bullets = await page.evaluate(() => {
                    try {
                        return document.querySelector('#productOverview_feature_div > .a-section').innerHTML;
                    } catch { return ''; }
        
                });
                description = await page.evaluate(() => {
                    try {
                        return document.querySelector('#featurebullets_feature_div > #feature-bullets').innerHTML;
                    } catch { return ''; }
                });
    
                number_of_reviews = await page.evaluate(() => {
                    try {
                        return document.querySelector('#acrCustomerReviewText').textContent;
                    } catch { return ''; }
                });
    
                number_of_answers = await page.evaluate(() => {
                   try {
                        return document.querySelector('#askATFLink').textContent;
                    } catch { return ''; } 
                });
    
                review_page_url = await page.evaluate(() => {
                    try {
                        return document.querySelector("a[data-hook='see-all-reviews-link-foot']").getAttribute('href');
                    } catch { return ''; }
                });
    
                if(review_page_url !== ''){
                    review_page_url = 'https://amazon.in'+review_page_url;
                }
    
                const thumbnails = await page.$$('.item.imageThumbnail');
    
                // Loop through the elements and click on each one
                for (let i = 0; i < thumbnails.length; i++) {
                    await thumbnails[i].click();
                    // Wait for some time (optional) to observe the result, replace with your use case
                    await new Promise(resolve => setTimeout(resolve, 500));
                }
    
                const image_divs = await page.$$('.image.item');
    
                for await (const image_div of image_divs) {
                    try {
                        let img = await page.evaluate(
                            el => el.querySelector('img').getAttribute('src'),
                            image_div
                        );
                            
                        images.push(img);
    
                    } catch { }
                }  
                
    
                let product_url = site_url;
    
                results.push({ title, price, mrp, product_url, number_of_ratings, number_of_reviews, number_of_answers, images, bullets, description, review_page_url });
                console.log(title);
                console.log(price);  
               
            }else{
                console.log('<========= Invalid Product Page ============>');
            }
            
           
            page_scrapped = page_scrapped + 1;

            if(page_scrapped >= number_of_products){
                isLastPage = true;
            }
            

        }

        await axios.post("https://jholashop.com/webhook/scrappy-product-details", {
            results: results
        }).then((response) => {
            console.log(response.data);
        })
        .catch((error) => {
            console.log(error);
        }); 

        console.log('<========== Products Scrapped : '+number_of_products+' ==========>');

        await browser.close();

    })();


}   


module.exports = {
    start
}