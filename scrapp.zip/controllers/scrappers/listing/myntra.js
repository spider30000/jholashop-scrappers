const axios = require('axios');

const start = (req, res) => {
    
    console.log('Myntra Scrapping for '+req.params.keyword+' keyword started');
    
    (async () => {
        
    
        let website = 'myntra';
        let keyword = req.params.keyword;
        let request_id = req.params.request_id;
        let isLastPage = false;
        let page_number = 1;
        let number_of_products = 0;
        while (!isLastPage) {

            // Navigate the page to a URL
            let query = req.params.keyword;
            query = query.replace(' ', '-')
            const site_url = 'https://myntra.com/'+query+'?rawQuery='+req.params.keyword+'&p='+page_number;
            await page.goto(site_url, {
                waitUntil: 'load'
            });

            let results = [];
            let data = [];

            await new Promise(resolve => setTimeout(resolve, 1000));

            let pagesAvailable = (await page.$('li.pagination-next > a')) !== null;
            
            await page.waitForSelector('.product-base', { visible: true });

            console.log('<========= Scrapping Page '+page_number+' Started ==========>');

            const productContainers = await page.$$('.product-base');

            for (const productContainer of productContainers) {

                let title = '';
                let price = '';
                let mrp = '';
                let product_url = '';
                let product_image = '';

                let product_id = '';
                let star_rating = '';
                let number_of_ratings = '';
                let number_of_reviews = '';

                try {
                    title = await page.evaluate(
                        el => el.querySelector('h4.product-product').textContent,
                        productContainer
                    );
                } catch { }
                try {
                    price = await page.evaluate(
                        el => el.querySelector('.product-discountedPrice').textContent,
                        productContainer
                    );
                    if(price == null){
                        price = await page.evaluate(
                            el => el.querySelector('.product-price').textContent,
                            productContainer
                        ); 
                    }
                } catch { }
                try {
                    mrp = await page.evaluate(
                        el => el.querySelector('span.product-strike').textContent,
                        productContainer
                    );
                } catch { }

                try {
                    product_url = await page.evaluate(
                        el => el.querySelector('a').getAttribute('href'),
                        productContainer
                    );
                    product_url = 'https://myntra.com/' + product_url;
                } catch { }

                try {
                    product_image = await page.evaluate(
                        el => el.querySelector('.product-imageSliderContainer > img').getAttribute('src'),
                        productContainer
                    );
                } catch { }

                try {
                    product_id = await page.evaluate(
                        el => el.getAttribute('data-asin'),
                        productContainer
                    );
                } catch { }

                try {
                    number_of_ratings = await page.evaluate(
                        el => el.querySelector('div.product-ratingsCount').textContent,
                        productContainer
                    );
                } catch { }


                if (product_url !== '') {
                    data.push({ title, price, mrp, product_url, product_image, product_id, star_rating, number_of_ratings, number_of_reviews });
                }

                number_of_products = number_of_products + 1;

                console.log(title);
                console.log(price);
                console.log(product_image);
                console.log(number_of_ratings);
                console.log(product_url);
                console.log('---------------  ===  ---------------');

            }

            results.push({website, request_id, keyword, page_number, data});


            await axios.post("https://jholashop.com/webhook/scrappy", {
                results: results
            }).then((response) => {
                console.log(response.data);
                console.log('<========= Page '+page_number+' Scrapping Completed ==========>');
                page_number = page_number + 1;
            })
            .catch((error) => {
                console.log(error);
            }); 

            page_number = page_number + 1;

            if(pagesAvailable){
                await page.waitForSelector('li.pagination-next > a', { visible: true });
                const isLast = (await page.$('li.pagination-next > a')) == null;
                isLastPage = isLast;
                if (!isLast) {
                    //await page.click('li.pagination-next > a');
                    //await page.waitForNavigation();
                }
            }else {
                isLastPage = true;
            }

            if(page_number > req.params.limit){
                isLastPage = true;
            }
            

        }


        console.log('<========== Products Found : '+number_of_products+' ==========>');

    })();

}


module.exports = {
    start
}