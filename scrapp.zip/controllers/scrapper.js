const amazon = require('./scrappers/listing/amazon');
const myntra = require('./scrappers/listing/myntra');
const ajio = require('./scrappers/listing/ajio');
const flipkart = require('./scrappers/listings/flipkart');
const amazonDetails = require('./scrappers/details/amazon');
const myntraDetails = require('./scrappers//details/myntra');
const flipkartDetails = require('./scrappers/details/flipkart');
const ajioDetails = require('./scrappers/details/ajio');
const { Cluster } = require("puppeteer-cluster");
const axios = require('axios');
const config = require('config');


const mapWebsite = (req, res) => {
    console.log(req.params);
    const website = req.params.website;
    if (website == 'amazon') {
        amazon.start(req, res);
    } else if (website == 'myntra') {
        myntra.start(req, res);
    } else if (website == 'flipkart') {
        flipkart.start(req, res);
    } else if (website == 'ajio') {
        ajio.start(req, res);
    } else {
        console.log('Invalid Website');
        res.render('404');
    }
}

const scrapeWebsite = (req, res) => {
    console.log(req.params);

    res.render('scrapping', { site: 'All websites' });

    const websites = [
        'amazon',
        'flipkart',
        'ajio'
    ];

    const proxyServer = 'brd.superproxy.io:22225';
    const proxyUsername = 'brd-customer-hl_4b2b55d2-zone-residential';
    const proxyPassword = 'f31tx7e626cl';

    (async () => {

        let status_on = false;
        while(!status_on){
            await axios.post("https://jholashop.com/webhook/scrappy-status", {
                status: 1,
                scrapper: config.get('scrapper.scrapper_id')
            }).then((response) => {
                status_on = true;
                console.log(response.data);
            })
            .catch((error) => {
                //console.log(error);
            });
        }

        const cluster = await Cluster.launch({
            concurrency: Cluster.CONCURRENCY_CONTEXT,
            maxConcurrency: 100,
            monitor: false,
            timeout: 6000000,
            puppeteerOptions: {
                headless: false,
                defaultViewport: false,
                userDataDir: "./tmp",
                ignoreHTTPSErrors: true,
                args: [`--proxy-server=${proxyServer}`]
            },
        });

        cluster.on("taskerror", (err, data) => {
            console.log(`Error crawling ${data}: ${err.message}`);
        });

        await cluster.task(async ({ page, data: website }) => {

            await page.setDefaultNavigationTimeout(0);

            await page.authenticate({
                username: proxyUsername,
                password: proxyPassword,
            });
            if (website == 'amazon') {
                let website = 'amazon';
                let keyword = req.params.keyword;
                let request_id = req.params.request_id;
                let isLastPage = false;
                let page_number = 1;
                let number_of_products = 0;
                while (!isLastPage) {

                    // Navigate the page to a URL
                    const site_url = 'https://www.amazon.in/s?k=' + req.params.keyword + '&page=' + page_number;
                    await page.goto(site_url, {
                        waitUntil: 'load'
                    });

                    let results = [];
                    let data = [];

                    let valid_page = (await page.$('.s-result-item.s-asin')) !== null;

                    if (valid_page) {

                        let pagesAvailable = (await page.$('.s-pagination-item.s-pagination-next')) !== null;

                        await page.waitForSelector('.s-main-slot.s-result-list.s-search-results.sg-row > .s-result-item.s-asin', { visible: true });

                        console.log('<========= Scrapping Page ' + page_number + ' Started ==========>');

                        const productContainers = await page.$$('.s-main-slot.s-result-list.s-search-results.sg-row > .s-result-item.s-asin');

                        for (const productContainer of productContainers) {
                            let title = '';
                            let price = '';
                            let mrp = '';
                            let product_url = '';
                            let product_image = '';

                            let product_id = '';
                            let star_rating = '';
                            let number_of_ratings = '';
                            let number_of_reviews = '';

                            try {
                                title = await page.evaluate(
                                    el => el.querySelector('h2 > a > span').textContent,
                                    productContainer
                                );
                            } catch { }
                            try {
                                price = await page.evaluate(
                                    el => el.querySelector('.a-price > span.a-offscreen').textContent,
                                    productContainer
                                );
                            } catch { }
                            try {
                                mrp = await page.evaluate(
                                    el => el.querySelector('.a-price.a-text-price > span.a-offscreen').textContent,
                                    productContainer
                                );
                            } catch { }

                            try {
                                product_url = await page.evaluate(
                                    el => el.querySelector('.a-link-normal').getAttribute('href'),
                                    productContainer
                                );
                                product_url = 'https://amazon.in' + product_url;
                            } catch { }

                            try {
                                product_image = await page.evaluate(
                                    el => el.querySelector('.s-image').getAttribute('src'),
                                    productContainer
                                );
                            } catch { }

                            try {
                                product_id = await page.evaluate(
                                    el => el.getAttribute('data-asin'),
                                    productContainer
                                );
                            } catch { }

                            try {
                                number_of_ratings = await page.evaluate(
                                    el => el.querySelector('a.a-link-normal.s-underline-text.s-underline-link-text.s-link-style > span.a-size-base.s-underline-text').textContent,
                                    productContainer
                                );
                            } catch { }


                            if (product_url !== '') {
                                data.push({ title, price, mrp, product_url, product_image, product_id, star_rating, number_of_ratings, number_of_reviews });
                            }

                            number_of_products = number_of_products + 1;

                        }

                        results.push({ website, request_id, keyword, page_number, data });


                        await axios.post("https://jholashop.com/webhook/scrappy", {
                            results: results
                        }).then((response) => {
                            console.log(response.data);
                            console.log('<========= Page ' + page_number + ' Scrapping Completed ==========>');
                        })
                        .catch((error) => {
                            console.log(error);
                        });

                        page_number = page_number + 1;

                        if (page_number == 1) {
                            if (pagesAvailable) {
                                await page.waitForSelector('.s-pagination-item.s-pagination-next', { visible: true });
                                let isLast = (await page.$('.s-pagination-item.s-pagination-next.s-pagination-disabled')) !== null;
                                if (page_number > req.params.limit) {
                                    isLast = true;
                                }
                                isLastPage = isLast;
                                if (!isLast) {
                                    //await page.click('.s-pagination-item.s-pagination-next');
                                    //await page.waitForNavigation();
                                }
                            } else {
                                isLastPage = true;
                            }
                        } else {
                            await page.waitForSelector('.s-pagination-item.s-pagination-next', { visible: true });
                            let isLast = (await page.$('.s-pagination-item.s-pagination-next.s-pagination-disabled')) !== null;
                            if (page_number > req.params.limit) {
                                isLast = true;
                            }
                            isLastPage = isLast;

                            if (!isLast) {
                                //await page.click('.s-pagination-item.s-pagination-next');
                                //await page.waitForNavigation();
                            }
                        }

                        if (page_number > req.params.limit) {
                            isLastPage = true;
                        }

                    } else {
                        console.log('<========== Invalid Page ==========>');
                    }

                }


                console.log('<========== Products Found : ' + number_of_products + ' ==========>');

            } else if (website == 'myntra') {
                let website = 'myntra';
                let keyword = req.params.keyword;
                let request_id = req.params.request_id;
                let isLastPage = false;
                let page_number = 1;
                let number_of_products = 0;
                while (!isLastPage) {

                    // Navigate the page to a URL
                    let query = req.params.keyword;
                    query = query.replace(' ', '-')
                    const site_url = 'https://myntra.com/' + query + '?rawQuery=' + req.params.keyword + '&p=' + page_number;
                    await page.goto(site_url, {
                        waitUntil: 'load'
                    });

                    let results = [];
                    let data = [];

                    let valid_page = (await page.$('.product-base')) !== null;

                    if (valid_page) {

                        await new Promise(resolve => setTimeout(resolve, 1000));

                        let pagesAvailable = (await page.$('li.pagination-next > a')) !== null;

                        await page.waitForSelector('.product-base', { visible: true });

                        console.log('<========= Scrapping Page ' + page_number + ' Started ==========>');

                        const productContainers = await page.$$('.product-base');

                        for (const productContainer of productContainers) {

                            let title = '';
                            let price = '';
                            let mrp = '';
                            let product_url = '';
                            let product_image = '';

                            let product_id = '';
                            let star_rating = '';
                            let number_of_ratings = '';
                            let number_of_reviews = '';

                            try {
                                title = await page.evaluate(
                                    el => el.querySelector('h4.product-product').textContent,
                                    productContainer
                                );
                            } catch { }
                            try {
                                price = await page.evaluate(
                                    el => el.querySelector('.product-discountedPrice').textContent,
                                    productContainer
                                );
                                if (price == null) {
                                    price = await page.evaluate(
                                        el => el.querySelector('.product-price').textContent,
                                        productContainer
                                    );
                                }
                            } catch { }
                            try {
                                mrp = await page.evaluate(
                                    el => el.querySelector('span.product-strike').textContent,
                                    productContainer
                                );
                            } catch { }

                            try {
                                product_url = await page.evaluate(
                                    el => el.querySelector('a').getAttribute('href'),
                                    productContainer
                                );
                                product_url = 'https://myntra.com/' + product_url;
                            } catch { }

                            try {
                                product_image = await page.evaluate(
                                    el => el.querySelector('.product-imageSliderContainer > img').getAttribute('src'),
                                    productContainer
                                );
                            } catch { }

                            try {
                                product_id = await page.evaluate(
                                    el => el.getAttribute('data-asin'),
                                    productContainer
                                );
                            } catch { }

                            try {
                                number_of_ratings = await page.evaluate(
                                    el => el.querySelector('div.product-ratingsCount').textContent,
                                    productContainer
                                );
                            } catch { }


                            if (product_url !== '') {
                                data.push({ title, price, mrp, product_url, product_image, product_id, star_rating, number_of_ratings, number_of_reviews });
                            }

                            number_of_products = number_of_products + 1;

                        }

                        results.push({ website, request_id, keyword, page_number, data });


                        await axios.post("https://jholashop.com/webhook/scrappy", {
                            results: results
                        }).then((response) => {
                            console.log(response.data);
                            console.log('<========= Page ' + page_number + ' Scrapping Completed ==========>');
                            page_number = page_number + 1;
                        })
                        .catch((error) => {
                            console.log(error);
                        });

                        page_number = page_number + 1;

                        if (pagesAvailable) {
                            await page.waitForSelector('li.pagination-next > a', { visible: true });
                            const isLast = (await page.$('li.pagination-next > a')) == null;
                            isLastPage = isLast;
                            if (!isLast) {
                                //await page.click('li.pagination-next > a');
                                //await page.waitForNavigation();
                            }
                        } else {
                            isLastPage = true;
                        }

                        if (page_number > req.params.limit) {
                            isLastPage = true;
                        }

                    } else {
                        console.log('<========== Invalid Page ==========>');
                    }


                }


                console.log('<========== Products Found : ' + number_of_products + ' ==========>');

            } else if (website == 'flipkart') {
                let website = 'flipkart';
                let keyword = req.params.keyword;
                let request_id = req.params.request_id;
                let isLastPage = false;
                let page_number = 1;
                let number_of_products = 0;
                while (!isLastPage) {

                    // Navigate the page to a URL
                    const site_url = 'https://www.flipkart.com/search?q=' + req.params.keyword + '&page=' + page_number;
                    await page.goto(site_url, {
                        waitUntil: 'load'
                    });

                    let results = [];
                    let data = [];

                    await new Promise(resolve => setTimeout(resolve, 1000));

                    let valid_page = (await page.$('div._13oc-S')) !== null;

                    if (valid_page) {

                        let pagesAvailable = (await page.$('._1LKTO3')) !== null;

                        console.log('<========= Scrapping Page ' + page_number + ' Started ==========>');

                        await page.waitForSelector('div._13oc-S', { visible: true });

                        let isGridLayout = (await page.$('.s1Q9rs')) !== null;

                        const productContainers = await page.$$('div._13oc-S > div');

                        await page.waitForSelector('div._13oc-S', { visible: true });

                        for (const productContainer of productContainers) {
                            let title = '';
                            let price = '';
                            let mrp = '';
                            let product_url = '';
                            let product_image = '';

                            let product_id = '';
                            let star_rating = '';
                            let number_of_ratings = '';
                            let number_of_reviews = '';

                            if (isGridLayout) {

                                //// Grid Layout

                                try {
                                    title = await page.evaluate(
                                        el => el.querySelector('.s1Q9rs').textContent,
                                        productContainer
                                    );
                                } catch { }

                                if (title == '') {
                                    try {
                                        title = await page.evaluate(
                                            el => el.querySelector('.IRpwTa').textContent,
                                            productContainer
                                        );
                                    } catch { }
                                }


                                try {
                                    price = await page.evaluate(
                                        el => el.querySelector('._30jeq3').textContent,
                                        productContainer
                                    );
                                } catch { }

                                try {
                                    mrp = await page.evaluate(
                                        el => el.querySelector('._3I9_wc').textContent,
                                        productContainer
                                    );
                                } catch { }


                                try {
                                    product_url = await page.evaluate(
                                        el => el.querySelector('a.s1Q9rs').getAttribute('href'),
                                        productContainer
                                    );
                                    product_url = 'https://flipkart.com' + product_url;
                                } catch { }

                                if (product_url == '') {
                                    try {
                                        product_url = await page.evaluate(
                                            el => el.querySelector('a._2UzuFa').getAttribute('href'),
                                            productContainer
                                        );
                                        product_url = 'https://flipkart.com' + product_url;
                                    } catch { }
                                }

                                try {
                                    product_image = await page.evaluate(
                                        el => el.querySelector('.CXW8mj > img').getAttribute('src'),
                                        productContainer
                                    );
                                } catch { }

                                if (product_image == '') {
                                    try {
                                        product_image = await page.evaluate(
                                            el => el.querySelector('._312yBx > img').getAttribute('src'),
                                            productContainer
                                        );
                                    } catch { }
                                }

                                try {
                                    product_id = await page.evaluate(
                                        el => el.getAttribute('data-id'),
                                        productContainer
                                    );
                                } catch { }

                                try {
                                    number_of_ratings = await page.evaluate(
                                        el => el.querySelector('._2_R_DZ').textContent,
                                        productContainer
                                    );
                                } catch { }


                            } else {

                                try {
                                    title = await page.evaluate(
                                        el => el.querySelector('._4rR01T').textContent,
                                        productContainer
                                    );
                                } catch { }
                                if (title == '') {
                                    try {
                                        title = await page.evaluate(
                                            el => el.querySelector('.IRpwTa').textContent,
                                            productContainer
                                        );
                                    } catch { }
                                }

                                try {
                                    price = await page.evaluate(
                                        el => el.querySelector('._30jeq3').textContent,
                                        productContainer
                                    );
                                } catch { }

                                try {
                                    mrp = await page.evaluate(
                                        el => el.querySelector('._3I9_wc').textContent,
                                        productContainer
                                    );
                                } catch { }


                                try {
                                    product_url = await page.evaluate(
                                        el => el.querySelector('a._1fQZEK').getAttribute('href'),
                                        productContainer
                                    );
                                    product_url = 'https://flipkart.com' + product_url;
                                } catch { }

                                if (product_url == '') {
                                    try {
                                        product_url = await page.evaluate(
                                            el => el.querySelector('a._2UzuFa').getAttribute('href'),
                                            productContainer
                                        );
                                        product_url = 'https://flipkart.com' + product_url;
                                    } catch { }
                                }

                                try {
                                    product_image = await page.evaluate(
                                        el => el.querySelector('.CXW8mj > img').getAttribute('src'),
                                        productContainer
                                    );
                                } catch { }

                                if (product_image == '') {
                                    try {
                                        product_image = await page.evaluate(
                                            el => el.querySelector('._312yBx > img').getAttribute('src'),
                                            productContainer
                                        );
                                    } catch { }
                                }

                                try {
                                    product_id = await page.evaluate(
                                        el => el.querySelector('div').getAttribute('data-id'),
                                        productContainer
                                    );
                                } catch { }

                                try {
                                    number_of_ratings = await page.evaluate(
                                        el => el.querySelector('._2_R_DZ > span > span').textContent,
                                        productContainer
                                    );
                                } catch { }

                            }


                            if (product_url !== '') {
                                data.push({ title, price, mrp, product_url, product_image, product_id, star_rating, number_of_ratings, number_of_reviews });
                            }

                            number_of_products = number_of_products + 1;

                        }

                        results.push({ website, request_id, keyword, page_number, data });


                        await axios.post("https://jholashop.com/webhook/scrappy", {
                            results: results
                        }).then((response) => {
                            console.log(response.data);
                            console.log('<========= Page ' + page_number + ' Scrapping Completed ==========>');
                            //page_number = page_number + 1;
                        }).catch((error) => {
                            console.log(error);
                        });

                        page_number = page_number + 1;

                        if (pagesAvailable) {
                            //await page.waitForSelector('._1LKTO3', { visible: true });
                            const isLast = (await page.$('._1LKTO3')) == null;
                            isLastPage = isLast;
                            if (!isLast) {
                                //await page.click('._1LKTO3');
                                //await page.waitForNavigation();
                            }
                        } else {
                            isLastPage = true;
                        }

                        if (page_number > req.params.limit) {
                            isLastPage = true;
                        }

                        if (page_number > 25) {
                            isLastPage = true;
                        }
                    } else {

                        let valid_results = (await page.$('._1YokD2._2GoDe3')) !== null;
                        if(valid_results){
                            isLastPage = true;
                        }
                        console.log('<========== Invalid Page ==========>');
                    }

                }

                console.log('<========== Products Found : ' + number_of_products + ' ==========>');

            } else if (website == 'ajio') {
                let website = 'ajio';
                let keyword = req.params.keyword;
                let request_id = req.params.request_id;
                let isLastPage = false;
                let page_number = 1;
                let number_of_products = 0;

                const site_url = 'https://www.ajio.com/search/?text=' + req.params.keyword;
                await page.goto(site_url, {
                    waitUntil: 'load'
                });

                let scroll = true;
                var scrolled = 0;
                var number_of_pages = req.params.limit;
                var number_of_scrolls = number_of_pages * 5;
                var product_count = 0;
                var product_div = 0;


                let valid_page = (await page.$('#products')) !== null;

                if (valid_page) {


                    console.log('============= Scrolling Page ==============');

                    while (scroll) {
                        await page.evaluate(async () => {
                            var totalHeight = 0;
                            var distance = 500;
                            var scrollHeight = document.body.scrollHeight;
                            window.scrollBy(0, distance);
                            totalHeight += distance;
                            if (totalHeight >= scrollHeight - window.innerHeight) {
                                scroll = false;
                            }
                        });
                        scrolled = scrolled + 1;
                        if (number_of_scrolls <= scrolled) {
                            scroll = false;
                        }
                        await new Promise(resolve => setTimeout(resolve, 3000 || DEF_DELAY));
                    }

                    console.log('========== Scrolling Done ===========');

                    await new Promise(resolve => setTimeout(resolve, 5000 || DEF_DELAY));
                    await page.waitForSelector('#products');
                    const productsHandles = await page.$$(
                        ".item.rilrtl-products-list__item.item"
                    );

                    let results = [];
                    let data = [];

                    for (const producthandle of productsHandles) {

                        product_div = product_div + 1;
                        let title = '';
                        let price = '';
                        let mrp = '';
                        let product_url = 'Null';
                        let product_image = 'Null';

                        let product_id = '';
                        let star_rating = '';
                        let number_of_ratings = '';
                        let number_of_reviews = '';

                        try {
                            title = await page.evaluate(
                                (el) => el.querySelector(".contentHolder > .nameCls").textContent,
                                producthandle
                            );
                        } catch (error) { }

                        try {
                            price = await page.evaluate(
                                (el) => el.querySelector(".price").textContent,
                                producthandle
                            );
                        } catch (error) { }

                        try {
                            mrp = await page.evaluate(
                                (el) => el.querySelector(".orginal-price").textContent,
                                producthandle
                            );
                        } catch (error) { }

                        try {
                            product_image = await page.evaluate(
                                (el) => el.querySelector(".imgHolder > div > img").getAttribute("src"),
                                producthandle
                            );
                        } catch (error) { }

                        try {
                            product_url = await page.evaluate(
                                (el) => el.querySelector("a.rilrtl-products-list__link").getAttribute("href"),
                                producthandle
                            );
                        } catch (error) { }

                        product_url = 'https://ajio.com' + product_url;

                        if (product_image !== null && product_image !== "Null") {

                            //Send To Server

                            data.push({ title, price, mrp, product_url, product_image, product_id, star_rating, number_of_ratings, number_of_reviews });

                            product_count = product_count + 1;
                            number_of_products = number_of_products + 1;

                            if (product_count > 50) {

                                results.push({ website, request_id, keyword, page_number, data });

                                await axios.post("https://jholashop.com/webhook/scrappy", {
                                    results: results
                                }).then((response) => {
                                    console.log(response.data);
                                    console.log('<========= Page ' + page_number + ' Scrapping Completed and Posted ==========>');
                                })
                                    .catch((error) => {
                                        console.log(error);
                                    });

                                page_number = page_number + 1;
                                product_count = 0;

                                results = [];
                                data = [];

                            }

                        }
                    }

                    if (data.length > 0) {

                        results.push({ website, request_id, keyword, page_number, data });

                        await axios.post("https://jholashop.com/webhook/scrappy", {
                            results: results
                        }).then((response) => {
                            console.log(response.data);
                            console.log('<========= Page ' + page_number + ' Scrapping Completed and Posted ==========>');
                        })
                            .catch((error) => {
                                console.log(error);
                            });

                        page_number = page_number + 1;
                        product_count = 0;

                        results = [];
                        data = [];

                    }
                } else {
                    console.log('<========== Invalid Page ==========>');
                }
                console.log('<========== Products Found : ' + number_of_products + ' ==========>');

            } else {
                console.log('Invalid Website');
            }

        });

        for (const website of websites) {
            await cluster.queue(website);
        }

        await cluster.idle();
        await cluster.close();

        let status_off = false;
        while(!status_off){
            await axios.post("https://jholashop.com/webhook/scrappy-status", {
                status: 0,
                scrapper: config.get('scrapper.scrapper_id')
            }).then((response) => {
                status_off = true;
                console.log(response.data);
            })
            .catch((error) => {
                //console.log(error);
            });
        }

        

    })();

}

const mapDetailsWebsite = (req, res) => {
    console.log(req.params);
    const website = req.params.website;
    if (website == 'amazon') {
        amazonDetails.start(req, res);
    } else if (website == 'myntra') {
        myntraDetails.start(req, res);
    } else if (website == 'flipkart') {
        flipkartDetails.start(req, res);
    } else if (website == 'ajio') {
        ajioDetails.start(req, res);
    } else {
        console.log('Invalid Website');
        res.render('404');
    }
}



const scrapeDetailsWebsite = (req, res) => {

    console.log(req.params);

    res.render('scrapping', { site: 'All websites' });

    const urls = req.body.urls;

    console.log(urls);

    (async () => {

        let results = [];

        const cluster = await Cluster.launch({
            concurrency: Cluster.CONCURRENCY_PAGE,
            maxConcurrency: 10,
            monitor: true,
            timeout: 600000,
            puppeteerOptions: {
                headless: false,
                defaultViewport: false,
                userDataDir: "./tmp"
            },
        });

        cluster.on("taskerror", (err, data) => {
            console.log(`Error crawling ${data}: ${err.message}`);
        });

        await cluster.task(async ({ page, data: url }) => {

            let website = url.website;

            console.log(website);

            if (website == 'amazon') {

            } else if (website == 'myntra') {

            } else if (website == 'flipkart') {

            } else if (website == 'ajio') {

            } else {
                console.log('Invalid Website');
            }

        });

        for (const url of urls) {
            await cluster.queue(url);
        }



        await cluster.idle();
        await cluster.close();

    })();

}



module.exports = {
    mapWebsite,
    mapDetailsWebsite,
    scrapeWebsite,
    scrapeDetailsWebsite
}